# Test report

**Executed:** `node tests/scenario.test.mjs` (Node 22, mocked LocalStorage) — store logic and string-render smoke checks of all five views. Result: PASS.
**Not executed:** any real-browser test (clicks, forms, mobile layout, console errors), GitHub Pages deployment, brand comparison against a rendered page.

| # | Criterion | Evidence | Status |
|---|---|---|---|
| 1 | B2B request + validation | Logic: negative, zero, blank, non-numeric quantity and blank location rejected. Form wiring untested in a browser | PARTIAL (logic PASS, UI UNVERIFIED) |
| 2 | Multi-farmer matching | 500 kg tomato A → 150+200+150; spinach shortfall 120 kg; past date → unmatched | PASS (logic) |
| 3 | Reservation safety | Over-allocation, negative qty, repeat confirm, competing request, cancel release, repeat cancel all tested | PASS (single-browser only; production needs a transactional backend) |
| 4 | Shared state | Reserved/delivered quantities and request status update across lots; farmer/buyer screens render from the same state (render smoke only) | PARTIAL |
| 5 | B2C commerce | Zero/over-stock rejected, cart cap, checkout total, stock reduced, empty-cart error | PASS (logic); UI UNVERIFIED |
| 6 | Persistence + reset | State written to storage; reset restores 2 requests, 10 lots, no orders. Real page refresh untested | PARTIAL |
| 7 | GitHub Pages deployment | Workflow written, not run | UNVERIFIED |
| 8 | Honest representation | Demo banner on every screen, "unverified" farm labels, no partner logos or live claims (code review) | PASS (inspection) |
| 9 | Reviewer walkthrough | Steps in README; scenario logic executed in tests, not clicked through in a browser | PARTIAL |

**Defect found during testing:** one wrong expectation in the test (cancelled orders are intentionally kept as history); test corrected, app unchanged.
**Known limitations:** no location matching, no delay alerts, no consumer location selector, no product images.
